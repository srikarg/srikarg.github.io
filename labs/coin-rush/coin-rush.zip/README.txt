Coin Rush
==============

A simple game created using [CraftyJS](http://craftyjs.com/).

Instructions
============

Open `index.html` to start up the game!

Move up: Up arrow key or W.

Move right: Right arrow key or D.

Move left: Left arrow key or A.

Collect the coins to gain points!

Let the coins fall to lose points!

Hit bombs and lose a life!

Press P to pause!

License
=======

The license for this game is the MIT License found [here](http://opensource.org/licenses/MIT).
